/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class gestionarValoracion {
   ArrayList<Valoracion> misValoraciones = new ArrayList<>();

    //Para que solo sea una instancia
    //Esto es un Singleton
    private gestionarValoracion() {
        // Constructor privado para evitar instanciación externa
    }

    private static gestionarValoracion instance;

    //Llamando a este metodo todos van a funcionar en la misma instancia, asi evitando errores
    public static synchronized gestionarValoracion getInstance() {//El synchronized es para que sea un solo hilo para que evitar que se creen otras instancias
        if (instance == null) {//Si instancia esta vacia
            instance = new gestionarValoracion();//Crea un nuevo objeto instancia de la clase gestionarValoración
        }
        return instance;//Retorna la instancia
    }

    //Fin de donde es para que solo haya una instancia para las operaciones
    
    
    
    //Cuando vas a transformar algo necesitas un void
    public void agregarValoracion(String nombre, String fecha, String correo, String negocio, String puntuacion) {
        Valoracion miValoracion = new Valoracion(nombre, fecha, correo, negocio, puntuacion);
        misValoraciones.add(miValoracion);

        //Este for solo era para ver que si se estan agregando
        /*for (Valoracion val : misValoraciones) {
            System.out.println("Nombre: " + val.getNombre());
            System.out.println("Fecha: " + val.getFecha());
            System.out.println("Correo: " + val.getCorreo());
            System.out.println("Negocio: " + val.getNegocio());
            System.out.println("Puntuacion: " + val.getPuntuacion());
            System.out.println("-------------------------------");
        }
         */
    }

    /**
     * Metodo que permite listar los datos de la contenedora variable
     *
     * @return toda la contenedora
     */
    public List<Valoracion> listarValoraciones() {
        return misValoraciones;
    }

    public void eliminarValoracion(String id) {

        //Utiliza un iterador para recorrer las contenedora variable
        Iterator<Valoracion> it = misValoraciones.iterator();

        //Recorrer lalista de valoraciones 
        while (it.hasNext()) {//Recorra hasta que no haya siguiente

            Valoracion v = it.next();//Valoracion  para acceder a la clase
            if (v.getCorreo().equals(id)) {//Si el correo de la valoracion es igual al que viene por parametro
                it.remove();//Eliminarlo
            }
        }
    }
    
    public Valoracion buscarValoracion(String correo){
        Valoracion  valBuscada=null;
        
        for(Valoracion v:misValoraciones){
            if(v.getCorreo().equals(correo)){
               valBuscada=v;
               break;
            }
        
        }
        
        return valBuscada;
    }
    
    public void editarValoracion(String correo, String nombre, String fecha, String negocio, String puntuacion) {//Recuerda que el id es el correo aqui
        Valoracion valEditar = null;

        for (Valoracion v : misValoraciones) {
            if (v.getCorreo().equals(correo)) {
                v.setNombre(nombre);
                v.setFecha(fecha);
                v.setCorreo(correo);
                v.setNegocio(negocio);
                v.setPuntuacion(puntuacion);
                break;
            }
        }

    }
       
}

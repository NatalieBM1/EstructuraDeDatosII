package com.mycompany.abo;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Natalie
 */
public class ABO {

    public static void main(String[] args) {

        // Insertar valores en el arbol
        Scanner numeros = new Scanner(System.in);
        ArbolBinario arbol = new ArbolBinario();
        boolean continuar = true;
        do {
            try {
                System.out.print("Ingrese un número entero: ");
                int numero = numeros.nextInt();
                if (arbol.existeNumero(numero)) {
                    System.out.println("El número ya existe en el árbol.");
                    System.out.print("¿Desea ingresar otro número? (y/n): ");
                    char respuesta = numeros.next().charAt(0);
                    continuar = (respuesta == 'y' || respuesta == 'Y');
                } else {
                    arbol.insertar(numero);
                    System.out.print("¿Desea ingresar otro número? (y/n): ");
                    char respuesta = numeros.next().charAt(0);
                    continuar = (respuesta == 'y' || respuesta == 'Y');
                }
            } catch (InputMismatchException e) {
                System.out.println("Dato incorrecto, no es un número entero.");
                numeros.next();
                System.out.print("¿Desea intentar ingresar otro número? (y/n): ");
                char respuesta = numeros.next().charAt(0);
                continuar = (respuesta == 'y' || respuesta == 'Y');
            }
        } while (continuar);

        // Imprimir valores en orden        
        System.out.println("VALORES DEL ARBOL EN ORDEN");
        arbol.imprimirPorNiveles();
    }
}

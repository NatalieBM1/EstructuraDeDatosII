/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.abo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Natalie
 */
public class ArbolBinario {

    Nodo raiz;

    // Constructor
    public ArbolBinario() {
        this.raiz = null;
    }

    /**
     * Insertar nueva raiz
     *
     * @param valor
     */
    public void insertar(int valor) {
        raiz = insertarRecursivo(raiz, valor);
    }

    /**
     * Metodo recursivo para hacer el recorrido del arbol
     *
     * @param nodo
     * @param valor
     * @return
     */
    private Nodo insertarRecursivo(Nodo nodo, int valor) {
        // Nodo padre o raiz
        if (nodo == null) {
            return new Nodo(valor);
        }

        //Hijos
        if (valor < nodo.valor) {
            nodo.izquierda = insertarRecursivo(nodo.izquierda, valor);
        } else {
            nodo.derecha = insertarRecursivo(nodo.derecha, valor);
        }
        return nodo;
    }

    // Imprimir
    public void imprimirInOrder() {
        imprimirOrdenRecursivo(raiz);
    }

    // Imprimir Orden Recursivo
    private void imprimirOrdenRecursivo(Nodo nodo) {
        if (nodo != null) {
            imprimirOrdenRecursivo(nodo.izquierda);
            System.out.println(nodo.valor + " ");
            imprimirOrdenRecursivo(nodo.derecha);
        }
    }

    // Número Duplicado
    public boolean existeNumero(int numero) {
        return existeNumeroRecursivo(raiz, numero);
    }

    private boolean existeNumeroRecursivo(Nodo nodo, int numero) {
        if (nodo == null) {
            return false;
        }
        if (nodo.valor == numero) {
            return true;
        }
        if (numero < nodo.valor) {
            return existeNumeroRecursivo(nodo.izquierda, numero);
        } else {
            return existeNumeroRecursivo(nodo.derecha, numero);
        }
    }

    // Imprimir el árbol binario por niveles
    public void imprimirPorNiveles() {
        List<List<String>> lines = new ArrayList<>();
        List<Nodo> nivelActual = new ArrayList<>();
        nivelActual.add(raiz);
        int altura = calcularAltura(raiz);
        int anchoMaximo = (int) Math.pow(2, altura) - 1;

        while (!nivelActual.isEmpty()) {
            List<String> lineaNivel = new ArrayList<>();
            List<Nodo> siguienteNivel = new ArrayList<>();

            for (Nodo nodo : nivelActual) {
                if (nodo == null) {
                    lineaNivel.add(null);
                    siguienteNivel.add(null);
                    siguienteNivel.add(null);
                } else {
                    lineaNivel.add(String.valueOf(nodo.valor));
                    siguienteNivel.add(nodo.izquierda);
                    siguienteNivel.add(nodo.derecha);
                }
            }

            lines.add(lineaNivel);
            nivelActual = siguienteNivel;

            boolean allNull = true;
            for (Nodo n : nivelActual) {
                if (n != null) {
                    allNull = false;
                    break;
                }
            }

            if (allNull) {
                break;
            }
        }

        int espacios = anchoMaximo;

        for (int i = 0; i < lines.size(); i++) {
            List<String> line = lines.get(i);
            int offset = (int) Math.pow(2, altura - i - 1) - 1;

            StringBuilder sb = new StringBuilder();
            for (String val : line) {
                sb.append(String.join("", Collections.nCopies(offset, "  ")));
                if (val == null) {
                    sb.append(" ");
                } else {
                    sb.append(val);
                }
                sb.append(String.join("", Collections.nCopies(offset, "  ")));
            }
            System.out.println(sb.toString());

            if (i < lines.size() - 1) {
                List<String> lineChild = new ArrayList<>();
                for (int j = 0; j < line.size(); j++) {
                    lineChild.add(line.get(j) != null ? "/" : "  ");
                    lineChild.add(line.get(j) != null ? "\\" : "  ");
                }

                StringBuilder sb2 = new StringBuilder();
                for (int j = 0; j < lineChild.size(); j += 2) {
                    sb2.append(String.join("", Collections.nCopies(offset - 1, "  ")));
                    sb2.append(lineChild.get(j));
                    sb2.append(" ");
                    sb2.append(lineChild.get(j + 1));
                    sb2.append(String.join("", Collections.nCopies(offset - 1, "  ")));
                }
                System.out.println(sb2.toString());
            }
        }
    }

    private int calcularAltura(Nodo nodo) {
        if (nodo == null) {
            return 0;
        }
        return 1 + Math.max(calcularAltura(nodo.izquierda), calcularAltura(nodo.derecha));
    }
}

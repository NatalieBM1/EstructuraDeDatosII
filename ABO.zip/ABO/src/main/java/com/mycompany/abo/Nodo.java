/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.abo;

/**
 *
 * @author Natalie
 */
public class Nodo {

    // Atributos de la clase    
    int valor;
    Nodo izquierda;
    Nodo derecha;

    // Constructor
    public Nodo(int valor) {
        this.valor = valor;
        this.izquierda = null;
        this.derecha = null;
    }

}

package Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mundo.ArbolNArio;
import mundo.Nodo;

@WebServlet(name = "servletNodo", urlPatterns = {"/servletNodo"})
public class servletNodo extends HttpServlet {
    private ArbolNArio arbol = new ArbolNArio();
    List<Nodo> listaNodos = new ArrayList<Nodo>();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Puedes implementar lógica común para GET y POST aquí si es necesario
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String option = request.getParameter("caso");
        String root = request.getParameter("raiz");
        String node = request.getParameter("nodo");
        String nodoMain = request.getParameter("nodoPadre");
        String errorMessage = null;

        try {
            if (option == null || option.isEmpty()) {
                throw new IllegalArgumentException("Opción inválida.");
            }

            switch (option) {
                case "0": // Asignar Raíz
                    if (root == null || root.trim().isEmpty()) {
                        throw new IllegalArgumentException("La raíz no puede estar vacía.");
                    }
                    int rootValue = Integer.parseInt(root.trim());

                    if (arbol.raiz != null) {
                        throw new IllegalArgumentException("La raíz ya ha sido asignada.");
                    }

                    arbol.asignarRaiz(rootValue);
                    listaNodos.add(arbol.raiz);
                    break;

                case "1": // Agregar Hijo a la Raíz
                    if (arbol.raiz == null) {
                        throw new IllegalStateException("No se puede agregar un hijo porque la raíz es null.");
                    }

                    if (node == null || node.trim().isEmpty()) {
                        throw new IllegalArgumentException("El nodo no puede estar vacío.");
                    }

                    int nodeValue = Integer.parseInt(node.trim());

                    if (arbol.existeNodo(nodeValue)) {
                        throw new IllegalArgumentException("El nodo con valor " + nodeValue + " ya existe.");
                    }

                    Nodo nuevoHijo = new Nodo(nodeValue);
                    arbol.raiz.agregarHijo(nuevoHijo);
                    listaNodos.add(nuevoHijo);
                    break;

                case "2": // Agregar Hijo a un Nodo Específico
                    if (arbol.raiz == null) {
                        throw new IllegalStateException("No se puede agregar un hijo porque la raíz es null.");
                    }

                    if (nodoMain == null || nodoMain.trim().isEmpty()) {
                        throw new IllegalArgumentException("El nodo padre no puede estar vacío.");
                    }

                    if (node == null || node.trim().isEmpty()) {
                        throw new IllegalArgumentException("El nodo no puede estar vacío.");
                    }

                    int nodoMainValue = Integer.parseInt(nodoMain.trim());
                    int childValue = Integer.parseInt(node.trim());

                    if (arbol.existeNodo(childValue)) {
                        throw new IllegalArgumentException("El nodo con valor " + childValue + " ya existe.");
                    }

                    Nodo nodoPadre = arbol.buscarNodo(arbol.raiz, nodoMainValue);
                    if (nodoPadre == null) {
                        throw new IllegalArgumentException("El nodo padre con valor " + nodoMainValue + " no existe.");
                    }

                    Nodo nuevoHijoEspecifico = new Nodo(childValue);
                    nodoPadre.agregarHijo(nuevoHijoEspecifico);
                    listaNodos.add(nuevoHijoEspecifico);
                    break;

                default:
                    throw new IllegalArgumentException("Opción no reconocida.");
            }

            // Realizar el recorrido preorden y enviar los datos al JSP
            arbol.recorridoPreorden();
            List<Nodo> preorderNumbers = arbol.returnArr();
            request.setAttribute("array", preorderNumbers);

        } catch (NumberFormatException e) {
            errorMessage = "Por favor, ingresa valores numéricos válidos.";
        } catch (IllegalArgumentException | IllegalStateException e) {
            errorMessage = e.getMessage();
        } catch (Exception e) {
            errorMessage = "Ocurrió un error inesperado: " + e.getMessage();
        }

        if (errorMessage != null) {
            // Enviar el mensaje de error al JSP
            request.setAttribute("error", errorMessage);
            // Asegúrate de mantener los valores ingresados para no perder la información
            request.setAttribute("caso", option);
            request.setAttribute("raiz", root);
            request.setAttribute("nodo", node);
            request.setAttribute("nodoPadre", nodoMain);
        }

        request.getRequestDispatcher("index.jsp").forward(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet para manejar operaciones en un Árbol N-ario";
    }
}

package mundo;

import java.util.ArrayList;
import java.util.List;

public class ArbolNArio {
    public Nodo raiz;
    private List<Nodo> recorrido = new ArrayList<>();

    public void asignarRaiz(int valor) {
        this.raiz = new Nodo(valor);
    }

    public void recorridoPreorden() {
        recorrido.clear();
        preorden(this.raiz);
    }

    private void preorden(Nodo nodo) {
        if (nodo == null) return;
        recorrido.add(nodo);
        for (Nodo hijo : nodo.getHijos()) {
            preorden(hijo);
        }
    }

    public List<Nodo> returnArr() {
        return recorrido;
    }

    public boolean existeNodo(int valor) {
        return buscarNodo(this.raiz, valor) != null;
    }

    public Nodo buscarNodo(Nodo actual, int valor) {
        if (actual == null) {
            return null;
        }

        if (actual.getValor() == valor) {
            return actual;
        }

        for (Nodo hijo : actual.getHijos()) {
            Nodo encontrado = buscarNodo(hijo, valor);
            if (encontrado != null) {
                return encontrado;
            }
        }

        return null;
    }
}
